# Roll-Em-Up Taquito’s — La Vista measured production v001

**Status: COMPLETE / VERIFIED** — requested visualization scope only; not construction/BIM certification.

Project: `/Users/claire/.openclaw/workspace/blender-workspace/roll-em-up-la-vista-production-v001`

## Deliverables

- `scene.blend` — complete model; **all actual walls visible and full height** when reopened.
- `renders/TopPlan.png` — 1200 × 2000 orthographic top view; over-opening lintels omitted **in the render only** to expose openings.
- `renders/Isometric.png` — 1700 × 1700 oblique orthographic view, complete walls.
- `renders/IsometricCutaway.png` — 1700 × 1700 additional illustration with explicitly named occluding walls hidden, revealing fixtures. See `verification/render-modes.json`.
- `manifest.json` — production success, SHA-256 and sizes of package files.
- `verification/scene-audit.json` — **148 passed checks**, 178 saved scene objects. Collection instances represent reusable equipment separately from their source meshes.
- `components/GSW-HS-1615S.blend` — reusable documented hand-sink component; both scene sinks instance this design.
- `specs/building.json`, `specs/measurement-provenance.json`, `scripts/` — reproducible architectural/equipment workflow and exact coordinate evidence.

## Source and scale

Project 269, issued for permit **2024-08-07**, FS-1 principal equipment plan; FS-2 cross-check dimensions; FS-3 elevation references.

Exact PDF preserved in `original/source.pdf`:
`22072b79da7ff91478b23d78938355ce6d1d62d8552bc8ea0a1cfb5349050bd6`

Authoritative intake: `/Users/claire/.openclaw/workspace/blender-workspace/roll-em-up-la-vista-measured-v001` — all 42 recorded files rehashed successfully; unchanged. Its earlier blocked status is historical, not this production status. Frank’s two blocker resolutions are recorded in `original/approvals.json`.

**Verified isotropic scale: 18 PDF points/foot = 1.5 points/inch.** Normalized PDF coordinates X-right/Y-down transform to Blender meters as X=(pdfX−1421.94)×0.3048/18, Y=(1363.02−pdfY)×0.3048/18; Z-up, floor datum zero. Blender internal coordinates are meters; display is imperial, scale_length=1.

| Cross-check | Measured length | Nominal | Residual |
|---|---:|---:|---:|
| Cooler width | 140.519938 in | 140.5 in | +0.019938 in |
| Cooler depth | 93.359945 in | 93.375 in | −0.015055 in |
| FS-2 long run | 263.000041 in | 263 in | +0.000041 in |
| FS-2 summed chain | 128 in | 128 in | 0 |
| FS-2 short references | 18 / 12 in | 18 / 12 in | 0 |

All 12 original calibration references retained. Whole-inch FS-2 annotations individually round by up to 0.481 in; opposing residuals cancel in the chain. Fractional-inch cooler checks agree within 0.021 in. Endpoint precision is approximately 0.04 real inch. No anisotropic scaling or forced fit. The cooler’s equipment outline, **not the surrounding architectural partition**, establishes its footprint.

## Geometry audit

| Item | Verified result |
|---|---|
| Full-height wall runs | **17**, each **10 ft / 3.048 m**, base Z=0 |
| Front counter pony partition | **3 connected runs** (long, diagonal, front return), each **36 in / 0.9144 m** |
| Other short partitions | Beverage, booth-north and entrance-screen partitions remain **10 ft**; no general pony-wall interpretation |
| Main inside width | **236.56 in** |
| Rear widened-bay inside width | **290.76 in** |
| Inside front-to-rear span | **703.64 in** |
| Restroom clear enclosure | **76 × 98 in**, west wall 6 in, north/south 5 in |
| Main side-wall thickness | **7.24 in**, measured rather than nominal substitution |
| Cooler exterior | **140.5 × 93.375 × 120 in**, exact scheduled XY and user height |
| Real openings | **10**: 5 door/passage voids and 5 simplified storefront window voids |
| Three-comp sink | **1**, GSW SE16203D18, **84.375 L × 26 D × 45 H in**, 36-in rim |
| Hand sinks | **2**, GSW HS-1615S, **15.75 W × 15.25 D in**, 34-in rim |
| Restroom fixtures | **1 toilet + 1 lavatory**, measured plan envelopes/orientation; approved approximate Z/shape |
| Booths | **2 singles + 3 doubles**, made from **8** reused single-component instances |

All wall Z bounds, bases and face thicknesses tested numerically. **Six cross-wall rays per opening** (three lateral points × two heights) confirmed real unblocked geometric voids across all wall meshes. Openings are not decorative planes. Small measured corner-completion prisms close the core builder’s butt-junction outer quadrants.

Door/passage heights use measured FS-3 evidence: kitchen/restroom/rear 126 points = 7 ft; front entrance 143.94 points; cooler door head 118.74 points above floor = 79.16 in. Wall-interruption widths are unframed void widths; fabrication-grade frame profiles, hardware and full door leaves are not invented. Storefront glazing is represented by measured rectangular voids without glass, detailed framing or transom subdivision.

## Sinks and fixture decisions

Original GSW manufacturer pages and PDFs are preserved in `evidence/`. Read-only HTTP retrieval used the manufacturer’s search controller and downloadable specification sheets; no browser/GUI.

- SE16203D18: PDF specifies 26 × 84-3/8 × 45 in, three 20 × 16 × 12-in bowls, two 18-in drainboards. Long axis north–south, backsplash **flush to the kitchen side of the restroom west wall**. Plan center y=644.28; back x=1653.78. The sink-specific outline is y≈581.10…707.46; the intake’s larger annotation also surrounded nearby excluded equipment. No such equipment was added.
- HS-1615S: manufacturer PDF/table specifies 15-1/4 D × 15-3/4 W × 13-3/8 H in, 9-3/4 × 12-1/2 × 5-5/8-in bowl, 7-3/4-in splash. Both sinks preserve measured wall offsets and wall-parallel centers. FS-3 elevation5 gives 34-in rim (813.48−762.48 points). No exact GSW reusable asset existed; the different Regency HS-17 library was not substituted.
- Generic FS-1 hand-sink symbols measure about 17 × 13.48 in; manufacturer dimensions control the physical component, with the measured backing-wall anchor and center retained. The three-comp plan symbol measures about 84.24 × 25.76 in; manufacturer envelope similarly controls. **These are symbol/component differences, not scale-calibration conflicts.**
- Simple sheet shells, supports and faucets are visualization detail, not shop drawings. Three-comp pre-rinse hardware, concealed plumbing, mounting brackets and additional shelves/equipment were intentionally excluded.
- Restroom toilet/lavatory metadata explicitly says **APPROXIMATE / VISUALIZATION ONLY / NON-CONSTRUCTION**, per approval. Toilet 17-in rim/30-in tank top and lavatory 34-in rim/6-in bowl depth are approved visualization choices, not measurements attributed to this PDF. Their plan envelopes and east-facing orientation match scaled source evidence.

Manufacturer references:

- https://gsw-usa.com/sinks/hand-sinks/wall-mount-hand-sink-with-welded-splash-guards
- https://gsw-usa.com/attachment?id_attachment=20
- https://gsw-usa.com/sinks/compartment-sinks/3-compartment-sink-2-drain-boards
- https://gsw-usa.com/attachment?id_attachment=51

## Booth reuse provenance

Source: `/Users/claire/.openclaw/workspace/blender-workspace/ronis-equipment-library/production-v003/american-tables-seating-qas-36-blk-source35-v008/asset.blend`

Source collection **ASSET**, 10 original mesh objects; SHA-256:
`0d42e5514df997b0b18160a4b0f04552aa295e17ccc3f88da834fa9200e84fdd`

Appended as `REUSED_ASSET_production_v003_v008`. All **10 saved mesh vertex/topology signatures** match the source signatures. Only instance X scale **48/46** changes width; Y/Z scale remains 1. Source envelope 46 × 24 × 36 in becomes **48 × 24 × 36 in** per single. Three pairs produce **48 × 48 × 36 in** assemblies, backs touching, seats facing opposite ways. Original asset file hash unchanged.

Every assembly’s saved bounds match its measured FS-1 rectangle. Top single faces down-plan, bottom single up-plan. This remains the prior **Approximate Layout Asset**, adapted with explicit approval, not an independently certified double-booth design. No replacement booth mesh was invented.

## Organization and exclusions

Collections: `Architecture/Walls`, `Restroom`, `WalkInCooler`, `Sinks/ThreeComp`, `Sinks/Hand`, `Seating/Booths`, and `VerificationPresentation`.

Only requested geometry is included. No cook line, additional equipment, loose tables, cabinetry/countertops, décor, ceiling or designed light fixtures. The floor is a **zero-thickness preview datum**, not an inferred structural slab. Cameras and neutral studio lights are explicitly preview-only. The complete tenant outline is modeled, not neighboring façade continuations outside the tenant space. Cooler enclosure is open-topped for verification, with a real east-side opening and no ceiling panel.

## Execution and verification

Official binary: `/Applications/Blender.app/Contents/MacOS/Blender`, **5.2.1 LTS**; GPT-6 execution worker. Every Blender command used `--background --factory-startup --python-exit-code 1`; no GUI, AppleScript, clicks, browser or third-party add-ons.

1. Strict building schema validated and official wrapper returned **0**, `architectural-core/manifest.json.status=success`; all wrapper output hashes rechecked.
2. `scripts/build_production.py` appended equipment into a new root scene; exit **0**.
3. `scripts/refine_verification_views.py` and `scripts/finish_surface_cleanup.py` made final visualization refinements; exits **0**. Initial build retained in `verification/initial-build/`.
4. Independent headless `scripts/audit_scene.py` reopened the **final saved scene**; exit **0**, **148/148 assertions passed**. See `verification/final-reopen-audit.log` and `verification/audit-execution.json`.
5. Final top, full isometric and cutaway PNGs visually inspected with `view_image`. PNG chunk CRC/decompression integrity verified; hashes bind inspection to final files.
6. Source PDF, prior intake, and source booth preservation verified. Final package file sizes/hashes checked by `scripts/verify_package.py`.

Recheck without modifying model geometry:

```sh
/Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python-exit-code 1 --python "/Users/claire/.openclaw/workspace/blender-workspace/roll-em-up-la-vista-production-v001/scripts/audit_scene.py"
python3 "/Users/claire/.openclaw/workspace/blender-workspace/roll-em-up-la-vista-production-v001/scripts/verify_package.py"
```

The audit rewrites its audit JSON with identical measurements; if Blender/version/runtime changes cause different report bytes, regenerate the manifest deliberately rather than misreporting a hash match. For a rebuild/revision, copy inputs/scripts to a **fresh version directory**; wrapper refuses existing paths. Current original intake and prior booth assets must remain unchanged.

A transient disk-space error prevented one log redirect before Blender started; it did not corrupt saved outputs. Free space recovered, final audit succeeded, and final PNG/file integrity checks passed. No unrelated data was removed.
